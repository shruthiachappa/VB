export enum Responsibility {
    User = 'ward_user',
    Admin = 'ward_admin',
    Cluster = 'cluster_user'
}