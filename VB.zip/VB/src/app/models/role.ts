export enum Role {
    Volunteer = 'Volunteer',
    Participant = 'Participant'
}