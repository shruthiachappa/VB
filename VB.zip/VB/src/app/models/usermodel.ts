export class UserModel {
    userId: string;
    name: string;
    phoneNo: Number;
    wardNo: Number;
    emailId: string;
    profession: string;
    type: string;
    password: string;
    state:boolean;
    responsibility:string;
}