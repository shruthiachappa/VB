import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedback-verification',
  templateUrl: './feedback-verification.component.html',
  styleUrls: ['./feedback-verification.component.scss']
})
export class FeedbackVerificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
