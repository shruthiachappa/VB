import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { AppService } from 'src/app/app.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IssueType } from 'src/app/models/issuetype';
import { IssueModel } from 'src/app/models/issuemodel';
import { Responsibility } from 'src/app/models/responsibility';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-feedback',
  templateUrl: './customer-feedback.component.html',
  styleUrls: ['./customer-feedback.component.scss']
})
export class CustomerFeedbackComponent implements OnInit {

  issueList: IssueModel[] = [];
  form: FormGroup;
  isSubmit: boolean = false;
  IssueTypeList: any = [];
  isClusterUser: boolean = false;
  isNormalUser: boolean = false;
  isDisableWardNo: boolean = true;

  constructor(private httpClient: HttpClient,
    private appService: AppService, private formBuilder: FormBuilder, private router: Router) {

  }

  ngOnInit() {
    this.form = this.formBuilder.group({
      wardNo: [''],
      issueId: [''],
      status: [''],
      type: [''],
      allWards: [false],
      filterText: ['']
    });

    this.Cancel();
    var data = JSON.parse(localStorage.getItem('issueFilters'));
    this.form.get('wardNo').setValue(data.wardNo);
    this.form.get('issueId').setValue(data.issueId);
    this.form.get('status').setValue(data.status);
    this.form.get('type').setValue(data.type);
    this.form.get('allWards').setValue(data.allWards);
    this.form.get('filterText').setValue(data.filterText);

    this.ViewReports();
  }

  ViewReports() {
    debugger;
    this.issueList = [];
    var wardNo = this.form.get('wardNo').value;
    var status = this.form.get('status').value;
    var type = this.form.get('type').value;
    var issueId = this.form.get('issueId').value;
    var allWards = this.form.get('allWards').value;
    var endpoint = environment.endPoint;

    // if (this.appService.currentUserSubject.value.responsibility == Responsibility.User) {
    //   endpoint = endpoint + 'issue/all?phoneNo=' + this.appService.currentUserSubject.value.phoneNo;
    // }
    // else {
    if (this.appService.currentUserSubject.value.responsibility == Responsibility.Admin || this.appService.currentUserSubject.value.responsibility == Responsibility.User) {
      wardNo = this.appService.currentUserSubject.value.wardNo.toString();
    }
    else if (this.appService.currentUserSubject.value.responsibility == Responsibility.Cluster)
      wardNo = this.form.get('wardNo').value;

    if (issueId != "" && issueId != null) {
      this.form.get('allWards').setValue(false);
      this.form.get('wardNo').setValue('');
      this.form.get('status').setValue('all');
      this.form.get('type').setValue('all');
      endpoint = endpoint + 'issue/id?issueId=' + issueId;
    }
    else if (allWards == true) {
      this.form.get('wardNo').setValue('');
      endpoint = endpoint + 'issue/all?wardNo=0';
    }
    else if (wardNo != "" && wardNo != null) {
      this.form.get('allWards').setValue(false);
      this.form.get('issueId').setValue('');
      endpoint = endpoint + 'issue/all?wardNo=' + wardNo;
    }

    this.ViewReportsService(endpoint).subscribe((resuser) => {
      debugger;
      var result = <any>resuser;
      if (type == "all")
        type = '';
      if (status == "all")
        status = '';
      if (result.return_code == 0) {
        this.issueList = result.issues;
        if (type != '' && status == '') {
          this.issueList = this.issueList.filter(x => x.issueType == type);
        }
        else if (type == '' && status != '') {
          this.issueList = this.issueList.filter(x => x.state == status);
        }
        else if (type != '' && status != '') {
          this.issueList = this.issueList.filter(x => x.issueType == type && x.state == status);
        }
        else
          this.issueList = this.issueList;
      }
    });
  }

  public ViewReportsService(endpoint: string) {
    return this.httpClient.get(endpoint, this.appService.headers);
  }

  Cancel() {
    debugger;
    this.IssueTypeList = IssueType;
    if (this.appService.currentUserSubject.value.responsibility == Responsibility.Cluster) {
      this.isClusterUser = true;
    }
    else
      this.isClusterUser = false;

    if (this.appService.currentUserSubject.value.responsibility == Responsibility.User) {
      this.isNormalUser = true;
    }
    else
      this.isNormalUser = false;
  }
  issue(item: any) {
    debugger;
    localStorage.setItem('issueFilters', JSON.stringify(this.form.value));
    localStorage.setItem('issue', JSON.stringify(item));
    this.router.navigate(['/issue']);
  }
}
