import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { AppService } from 'src/app/app.service';
import { environment } from 'src/environments/environment';
import { Responsibility } from 'src/app/models/responsibility';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.scss']
})
export class UserRegistrationComponent implements OnInit {

  form: FormGroup;
  submitted = false;
  isNotCluster: boolean = true;
  issueId: string = '';
  message: string = '';
  location: any;

  constructor(private formBuilder: FormBuilder,
    private httpClient: HttpClient,
    private appService: AppService) { }

  ngOnInit() {
    this.form = this.formBuilder.group({
      wardNo: ['', Validators.required],
      wardAdmin: ['', Validators.required],
      wardContactNo: ['', Validators.required],
      type: ['Select Type', Validators.required],
      location: [''],
      summary: ['', Validators.required],
      description: [''],
      isAnonymous: [false],
      isCurrentLocation: [false]
    });
    debugger;
    this.Cancel();
    if (this.appService.currentUserSubject.value.responsibility == Responsibility.Cluster)
      this.isNotCluster = false;
    debugger;
    this.form.get('wardNo').setValue(this.appService.currentUserSubject.value.wardNo);
  }

  get f() { return this.form.controls; }

  Cancel() {
    debugger;
    this.issueId = '';
    this.submitted = false;
    this.isNotCluster = true;
    this.form.get('wardNo').setValue(this.appService.currentUserSubject.value.wardNo);
    this.form.get('type').setValue(null);
    this.form.get('location').setValue('');
    this.form.get('summary').setValue('');
    this.form.get('description').setValue('');
    this.form.get('isAnonymous').setValue(false);
    this.form.get('isCurrentLocation').setValue(false);
    this.form.reset();
    this.message = '';
    this.form.get('wardNo').setValue(this.appService.currentUserSubject.value.wardNo);
  }

  onSubmit() {
    debugger;
    var type = this.form.get('type').value;
    var location = this.form.get('location').value;
    var summary = this.form.get('summary').value;
    if (type != '' && type != null && location != '' && location != null && summary != '' && summary != null) {
      this.RaiseIssueService(this.form.value).subscribe((resultUsers) => {
        debugger;
        var result = <any>resultUsers;
        if (result.return_code == 0) {
          this.Cancel();
          this.submitted = true;
          this.issueId = result.issueId;
        }
        else {
          this.submitted = false;
          this.message = result.message;
        }
      });
    }
    else {
      this.submitted = false;
      this.appService.validateAllFormFields(this.form);
    }
  }

  setCurrentLocation() {
    debugger;
    var value = this.form.get('isCurrentLocation').value;
    var lat;
    var lng;
    if (value) {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position: Position) => {
          if (position) {
            lat = position.coords.latitude;
            lng = position.coords.longitude;
            var val = "https://maps.google.com/?q=" + lat + "," + lng;
            console.log(val);
            this.form.get('location').setValue(val);
          }
        },
          (error: PositionError) => console.log(error));
      } else {
        alert("Sorry. Cannot find location. Please enter by yourself");
      }
    }
    else {
      this.form.get('location').setValue('');
    }
  }

  public RaiseIssueService(data: any) {
    var endpoint = environment.endPoint + 'issue/create';
    var obj = {
      wardNo: this.appService.currentUserSubject.value.wardNo,
      phoneNo: this.appService.currentUserSubject.value.phoneNo.toString(),
      issueType: this.form.get('type').value,
      issueSubtype: '',
      location: this.form.get('location').value,
      anonymousFlag: this.form.get('isAnonymous').value,
      raiserName: this.appService.currentUserSubject.value.name,
      summary: this.form.get('summary').value,
      description: this.form.get('description').value,
    }
    return this.httpClient.post(endpoint, obj, this.appService.headers);
  }
}
