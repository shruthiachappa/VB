import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Responsibility } from 'src/app/models/responsibility';
import { AppService } from 'src/app/app.service';
import { UserModel } from 'src/app/models/usermodel';

declare interface RouteInfo {
  path: string;
  title: string;
  icon: string;
  class: string;
  role: string[];
}
export const ROUTES: RouteInfo[] = [
  // { path: '/dashboard', title: 'Dashboard', icon: 'ni-tv-2 text-primary', class: '' },
  {
    path: '/user-registration', title: 'Raise Issue', icon: 'ni-single-02 text-yellow', class: '',
    role: [Responsibility.User, Responsibility.Admin, Responsibility.Cluster]
  },
  // { path: '/customer-profile', title: 'Customer Profile', icon: 'ni-planet text-blue', class: '' },
  {
    path: '/customer-feedback', title: 'Issue Reports', icon: 'ni-bullet-list-67 text-red', class: '',
    role: [Responsibility.User, Responsibility.Admin, Responsibility.Cluster]
  },
  {
    path: '/user-roles', title: 'Ward Users', icon: 'ni-planet text-blue', class: '',
    role: [Responsibility.Admin, Responsibility.Cluster]
  },
  {
    path: '/logout', title: 'Log Out', icon: 'ni-button-power text-blue', class: '',
    role: [Responsibility.User, Responsibility.Admin, Responsibility.Cluster]
  },
  // { path: '/feedback-verification', title: 'Feedback Verification', icon: 'ni-key-25 text-info', class: '' },
  // { path: '', title: 'Reports', icon: 'ni-bullet-list-67 text-red', class: '' },
  //  { path: '/icons', title: 'Icons',  icon:'ni-planet text-blue', class: '' },
  // { path: '/maps', title: 'Maps',  icon:'ni-pin-3 text-orange', class: '' },
  //  { path: '/user-profile', title: 'User profile', icon: 'ni-single-02 text-yellow', class: '' },
  //  { path: '/tables', title: 'Tables', icon: 'ni-bullet-list-67 text-red', class: '' },
  // { path: '/login', title: 'Login', icon: 'ni-key-25 text-info', class: '' },
  // { path: '/register', title: 'Register', icon: 'ni-circle-08 text-pink', class: '' }
];

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  public menuItems: any[];
  public isCollapsed = true;
  name: string;

  constructor(private router: Router, private appService: AppService) { }

  ngOnInit() {
    debugger;
    const currentUser = <UserModel>(JSON.parse(localStorage.getItem('currentUser')));
    this.name = "Welcome " + currentUser.name;
    var userRoutes = ROUTES.filter(x => x.role.includes(currentUser.responsibility));
    this.menuItems = userRoutes.filter(menuItem => menuItem);
    this.router.events.subscribe((event) => {
      this.isCollapsed = true;
    });
  }
}
