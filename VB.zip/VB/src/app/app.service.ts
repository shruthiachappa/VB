import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormGroup, FormControl } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { UserModel } from './models/usermodel';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  OTPCount: number = 3;
  headers: any;
  wardList: any[];
  public currentUserSubject: BehaviorSubject<UserModel>;
  constructor() {
    this.OTPCount = 3;
    this.headers = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'OPTIONS,GET,PUT,POST,DELETE'
      })
    }
   // this.getWardDetails();
  }
  validateAllFormFields(formGroup: FormGroup) {         //{1}
    Object.keys(formGroup.controls).forEach(field => {  //{2}
      const control = formGroup.get(field);             //{3}
      if (control instanceof FormControl) {             //{4}
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {        //{5}
        this.validateAllFormFields(control);            //{6}
      }
    });
  }
  getWardDetails() {
    var obj = {
      wardNo: '197 - Uttrahalli',
      value: 197
    }
    this.wardList.push(obj);
    obj.value = 196;
    obj.wardNo = '196 - Jayanagar';
    this.wardList.push(obj);
  }
}
